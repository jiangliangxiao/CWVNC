package ceka.lhr.noise.CWVNC;

import java.awt.RenderingHints.Key;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.converters.FileSaver;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.Worker;
import ceka.lhr.noise.CENC;
import ceka.lhr.noise.LDNC;
import ceka.lhr.noise.AVNC.AdaptiveClassificationFilter;
import ceka.lhr.noise.AVNC.VoteCorrection;
import ceka.lhr.noise.AVNC.WorkerStat;
import ceka.noise.ClassificationFilter;
import ceka.noise.PolishingLabels;
import ceka.noise.SelfTrainCorrection;
import ceka.noise.clustering.ClusterCorrection;
import ceka.simulation.MockWorker;
import ceka.simulation.SingleQualLabelingStrategy;
import ceka.utils.DatasetManipulator;
import ceka.utils.Stochastics;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.clusterers.Clusterer;
import weka.clusterers.SimpleKMeans;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;

public class Test {

	private static String[] dataSetName = {"anneal","audiology","autos","balance-scale","biodeg","breast-cancer","breast-w","car","credit-a","credit-g",
	"diabetes","heart-c","heart-h","heart-statlog","hepatitis","horse-colic","hypothyroid","ionosphere","iris","kr-vs-kp","labor","lymph","mushroom","segment",
	"sick","sonar","spambase","tic-tac-toe","vehicle","vote","vowel","waveform","zoo"};
	
//	private static String[] dataSetName = {"income94L10","music_genere"};
	
	public Dataset readDataset(int m_choose) throws Exception{
		String dataDir = "D:\\study information\\Code\\cekaspace\\MyCekaApp\\data\\synthetic\\";
		String arffPath= dataDir + dataSetName[m_choose]+"\\"+dataSetName[m_choose]+".arff";
		Dataset dataset = FileLoader.loadFile(arffPath);
		return dataset;
	}

	public Dataset readRealDataset(int m_choose) throws Exception{	
		String dataDir = "D:\\study information\\Code\\cekaspace\\MyCekaApp\\data\\real-world\\";
		String arffXPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".arffx";
		String arffPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".arff";
		String goldPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".gold.txt";
		String responsePath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".response.txt";

		Dataset dataset;
		try {
			dataset = FileLoader.loadFileX(responsePath, goldPath, arffXPath);
		} catch (Exception e) {
			dataset = FileLoader.loadFile(responsePath, goldPath, arffPath);
		}
		
		return dataset;
	}
		
	public static Dataset InstancesToDataset(Instances instances,Dataset dataset1) {
		Dataset dataset = new Dataset(instances,instances.numInstances());
		for(int m = 0;m < dataset1.getCategorySize();m++) {
			Category cate = dataset1.getCategory(m);
			dataset.addCategory(cate.copy());
		}
		for(int i = 0;i < instances.numInstances();i++) {
			Instance instance = instances.instance(i);
			Integer truevalue = (int)instance.classValue();
			Example example = new Example(instance);
			Label truelabel = new Label(null, truevalue.toString(), example.getId(), "creat");
			example.setTrueLabel(truelabel);
			dataset.addExample(example);	
		}
		return dataset;
	}
	
	public static double randdouble(double max, double min) {
		return (Math.random() * (max - min) + min) ;
	}
	
	public static Dataset copyDataset(Dataset dataset) {
		Dataset copyDataset = new Dataset(dataset, 0);
		for (int k = 0; k < dataset.getExampleSize(); k++) {
			Example example = dataset.getExampleByIndex(k);
			copyDataset.addExample(example);
		}
		for (int k = 0; k < dataset.getCategorySize(); k++) {
			Category category = dataset.getCategory(k);
			copyDataset.addCategory(category);
		}
		for (int k = 0; k < dataset.getWorkerSize(); k++) {
			Worker worker = dataset.getWorkerByIndex(k);
			copyDataset.addWorker(worker);
		}
		return copyDataset;
	}
			
	public double getNoiseRatio(Dataset dataset) throws Exception{
		int count = 0;
		for(int i = 0;i < dataset.getExampleSize();i++) {
			if(dataset.getExampleByIndex(i).getIntegratedLabel().getValue() != dataset.getExampleByIndex(i).getTrueLabel().getValue()) {
				count++;
			}
		}
		return 100*(double)count/dataset.getExampleSize();
	}
	
	public static int max(int[] counts) throws Exception{
		int maxCount=counts[0];
		for(int i=0;i<counts.length;i++) {
			if(counts[i]>maxCount) maxCount=counts[i];
		}
		return maxCount;
	}
	
	public static int randint(int min, int max) {
		return (int) (Math.random() * (max - min) + min) ;
	}

	public static int[] sufferArray(int[] tempArray) {
		Random r = new Random();
		for (int i = 0; i < tempArray.length; i++) {
			int randomIndex = r.nextInt(tempArray.length);
			int temp = tempArray[i];
			tempArray[i] = tempArray[randomIndex];
			tempArray[randomIndex] = temp;
		}
		return tempArray;
	}
	
	public static Dataset simulate(Dataset dataset,int numOfWorkers) throws Exception {
		int numCategory = dataset.getCategorySize();
		Dataset tempDataset = copyDataset(dataset);
		MockWorker[] mockworkers=new MockWorker[numOfWorkers];
		
		int[] tempIndex = new int[numCategory];
		for(int i=0; i<numCategory; i++) {
			tempIndex[i] = i;
		}
		
		for(int w = 0;w < numOfWorkers;w++) {
			double tempQuality = randdouble(0.9999, 1.0);
			SingleQualLabelingStrategy tempStrategy = new SingleQualLabelingStrategy(tempQuality);
			mockworkers[w]=new MockWorker(String.valueOf(w));
			mockworkers[w].setSingleQuality(tempQuality);	
			mockworkers[w].labeling(tempDataset, tempStrategy);
		}
		
		for(int w = 0;w < numOfWorkers;w++) {
			Worker tempWorker = tempDataset.getWorkerByIndex(w);
			
			tempIndex = sufferArray(tempIndex);

			double tempQuality1 = randdouble(0.7, 0.9);
			double tempQuality2 = randdouble(0.4, 0.6);
			if(dataset.getCategorySize() > 3) {
				tempQuality1 = randdouble(0.7, 0.9);
				tempQuality2 = randdouble(0.4, 0.5);
			}
			
			for(int i=0; i<tempDataset.getExampleSize(); i++) {
				Example tempExample = tempDataset.getExampleByIndex(i);
				int tempClass = tempExample.getNoisyLabelByWorkerId(tempWorker.getId()).getValue();
			
				int tempMark = 0;
				if(dataset.getCategorySize() == 2) {
					for(int j=0; j<1; j++) {
						if(tempIndex[j] == tempClass) {
							tempMark = 1;
							break;
						}
					}
				}else {
					for(int j=0; j<numCategory/3; j++) {
						if(tempIndex[j] == tempClass) {
							tempMark = 1;
							break;
						}
					}
				}
				
				double tempProb = randdouble(0.0, 1.0);
				Random random = new Random();
				int newClass = random.nextInt(numCategory);
				
				if(tempMark == 1) {
					if(tempProb > tempQuality1) {
						while(newClass == tempClass)
							newClass = random.nextInt(numCategory);
						tempExample.getNoisyLabelByWorkerId(tempWorker.getId()).setValue(newClass);
					}
				}
				else {
					if(tempProb > tempQuality2) {
						while(newClass == tempClass)
							newClass = random.nextInt(numCategory);
						tempExample.getNoisyLabelByWorkerId(tempWorker.getId()).setValue(newClass);
					}
				}
			}
		}
		
		MajorityVote mv=new MajorityVote();
		mv.doInference(tempDataset);
		return tempDataset;
	}
	
	
	public static void main(String[] args){
		int times = 10;
		double noiseRatio_MV=0.0;
		double noiseRatio_PL=0.0;
		double noiseRatio_STC=0.0;
		double noiseRatio_CC=0.0;
		double noiseRatio_AVNC=0.0;
		double noiseRatio_CENC=0.0;
		double noiseRatio_CWVNC=0.0;
		double noiseRatio_LDNC=0.0;
		
		double meanNoiseRatio_MV=0.0;
		double meanNoiseRatio_PL=0.0;
		double meanNoiseRatio_STC=0.0;
		double meanNoiseRatio_CC=0.0;
		double meanNoiseRatio_AVNC=0.0;
		double meanNoiseRatio_CENC=0.0;
		double meanNoiseRatio_LDNC=0.0;
		double meanNoiseRatio_CWVNC=0.0;
		
		try {
			String resultPath="D:\\study information\\Code\\CEKA\\result\\synthetic\\1.1.txt";
//			String resultPath="D:\\study information\\Code\\CEKA\\result\\real-world\\1.1.txt";
			FileOutputStream f=new FileOutputStream(new File(resultPath));
			PrintStream result=new PrintStream(f);
			result.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset","MV","PL","STC","CC","AVNC","CENC","LDNC","CWVNC");
			result.println();
			
			for(int i=0;i<dataSetName.length;i++){
				double tempNoiseRatio_MV=0.0;
				double tempNoiseRatio_PL=0.0;
				double tempNoiseRatio_STC=0.0;
				double tempNoiseRatio_CC=0.0;
				double tempNoiseRatio_AVNC=0.0;
				double tempNoiseRatio_CENC=0.0;
				double tempNoiseRatio_LDNC=0.0;
				double tempNoiseRatio_CWVNC=0.0;
				for(int m = 0;m < times;m++) {
					
					Test experiment=new Test();
					Dataset dataset=experiment.readDataset(i);
//					Dataset dataset=experiment.readRealDataset(i);
				
					Dataset resDataset = copyDataset(dataset);
					
					MajorityVote mv=new MajorityVote();
					mv.doInference(resDataset);
					for(int e = 0;e < dataset.getCategorySize();e++) {
						Category cate = dataset.getCategory(e);
						resDataset.addCategory(cate);
					}
					resDataset = simulate(dataset,5);
					noiseRatio_MV=experiment.getNoiseRatio(resDataset);
				
					//PL
					Dataset tempDataset1=experiment.copyDataset(resDataset);
					Classifier classifier1=new J48();
					PolishingLabels pl=new PolishingLabels(classifier1);
					Dataset dataset_corrected_pl=pl.polishLabels(tempDataset1);
					noiseRatio_PL=experiment.getNoiseRatio(dataset_corrected_pl);
					System.out.println("PL Completed!");
				
					//STC
					Dataset tempDataset2=experiment.copyDataset(resDataset);
					Classifier[] classifiers2=new Classifier[1];
					classifiers2[0]=new J48();
					ClassificationFilter cf1=new ClassificationFilter(10);
					cf1.filterNoise(tempDataset2, classifiers2);
					Dataset cleanSet1=cf1.getCleansedDataset();
					Dataset noiseSet1=cf1.getNoiseDataset();
				
					Dataset[] tempdata=new Dataset[2];
					SelfTrainCorrection stc=new SelfTrainCorrection(cleanSet1,noiseSet1,0.8);
					Classifier classifier3=new J48();
					tempdata=stc.correction(classifier3);
					DatasetManipulator.addAllExamples(tempdata[0], tempdata[1]);
					noiseRatio_STC=experiment.getNoiseRatio(tempdata[0]);
					System.out.println("STC Completed!");
				
					//CC
					Dataset tempDataset3=experiment.copyDataset(resDataset);
					int numClusters=10;
					Clusterer[] clusterers=new Clusterer[numClusters];
					for(int c=0;c<numClusters;c++){
						int k=(int)(((double)(c+1)/(double)(numClusters))*(tempDataset3.getExampleSize()/2.0));
						if(c==0) k=k+2;
						SimpleKMeans simpleKMeans=new SimpleKMeans();
						simpleKMeans.setMaxIterations(200);
						simpleKMeans.setNumClusters(k);
						clusterers[c]=simpleKMeans;
					}
					
					String tempPath="D:\\study information\\Code\\CEKA\\result\\output\\"+dataSetName[i]+m+".arff";
					FileSaver.saveDatasetArff(tempDataset3, tempPath);
					ClusterCorrection cc=new ClusterCorrection(tempDataset3,clusterers);
					Dataset dataset_corrected_cc=cc.correction();
					noiseRatio_CC=experiment.getNoiseRatio(dataset_corrected_cc);
					System.out.println("CC Completed!");

					//AVNC
					Dataset tempDataset4=experiment.copyDataset(resDataset);
					
					WorkerStat workerStat=new WorkerStat();
					double estimatedMeanProb=workerStat.calculateEstimatedMeanAcc(resDataset);
					double integratedCorrectProb=Stochastics.binomialIntegration(9, estimatedMeanProb);
					int nfold=10;
					int nModel=5;
					AdaptiveClassificationFilter acf=new AdaptiveClassificationFilter(nfold,nModel);
					acf.setMinEstimatedNoiseProportion(1-integratedCorrectProb);
					acf.setMaxEstimatedNoiseProportion(1-estimatedMeanProb);
					
					Classifier[] classifiers4=new Classifier[5];
					for(int k=0;k<5;k++)
						classifiers4[k]=new J48();
					acf.filterNoise(tempDataset4, classifiers4);
					Dataset cleanSet2=acf.getCleansedDataset();
					Dataset noiseSet2=acf.getNoiseDataset();
					Dataset[] highDatasets=acf.getHighQualityDatasets();
					
					VoteCorrection corrector=new VoteCorrection();
					corrector.correct(noiseSet2, highDatasets, classifiers4, (int)(highDatasets.length*0.5));
					for(int k=0;k<noiseSet2.getExampleSize();k++)
						cleanSet2.addExample(noiseSet2.getExampleByIndex(k));
					noiseRatio_AVNC=experiment.getNoiseRatio(cleanSet2);
					System.out.println("AVNC Completed!");
				
					//CENC
					Dataset tempDataset5=experiment.copyDataset(resDataset);
					CENC cenc=new CENC(10,0.1);
					Classifier classifier5=new J48();
					Dataset dataset_corrected_cenc=cenc.cenc(tempDataset5, classifier5);
					noiseRatio_CENC=experiment.getNoiseRatio(dataset_corrected_cenc);
					System.out.println("CENC Completed!");
				
					// LDNC
					Dataset tempDataset8=experiment.copyDataset(resDataset);
					LDNC ldnc=new LDNC(0.2);
					Classifier classifier10=new J48();
					Dataset dataset_corrected_ldnc=ldnc.ldnc(tempDataset8, classifier10);
					noiseRatio_LDNC=experiment.getNoiseRatio(dataset_corrected_ldnc);
					System.out.println("LDNC Completed!");

					// CWVNC
					Dataset tempDataset7=experiment.copyDataset(resDataset);
					CWVNC newnc = new CWVNC();
					Dataset dataset_corrected_cwvnc = newnc.CWVNC(tempDataset7);
					noiseRatio_CWVNC = experiment.getNoiseRatio(dataset_corrected_cwvnc);
					System.out.println("CWVNC Completed");
					
				
					tempNoiseRatio_MV+=noiseRatio_MV;
					tempNoiseRatio_PL+=noiseRatio_PL;
					tempNoiseRatio_STC+=noiseRatio_STC;
					tempNoiseRatio_CC+=noiseRatio_CC;	
					tempNoiseRatio_AVNC+=noiseRatio_AVNC;
					tempNoiseRatio_CENC+=noiseRatio_CENC;
					tempNoiseRatio_LDNC+=noiseRatio_LDNC;
					tempNoiseRatio_CWVNC+=noiseRatio_CWVNC;
				}
				tempNoiseRatio_MV/=times;
				tempNoiseRatio_PL/=times;
				tempNoiseRatio_STC/=times;
				tempNoiseRatio_CC/=times;	
				tempNoiseRatio_AVNC/=times;
				tempNoiseRatio_CENC/=times;
				tempNoiseRatio_LDNC/=times;
				tempNoiseRatio_CWVNC/=times;
				
				meanNoiseRatio_MV+=tempNoiseRatio_MV;
				meanNoiseRatio_PL+=tempNoiseRatio_PL;
				meanNoiseRatio_STC+=tempNoiseRatio_STC;
				meanNoiseRatio_CC+=tempNoiseRatio_CC;
				meanNoiseRatio_AVNC+=tempNoiseRatio_AVNC;
				meanNoiseRatio_CENC+=tempNoiseRatio_CENC;
				meanNoiseRatio_LDNC+=tempNoiseRatio_LDNC;
				meanNoiseRatio_CWVNC+=tempNoiseRatio_CWVNC;
		
				result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataSetName[i],tempNoiseRatio_MV,tempNoiseRatio_PL,tempNoiseRatio_STC,tempNoiseRatio_CC,tempNoiseRatio_AVNC,tempNoiseRatio_CENC,tempNoiseRatio_LDNC,tempNoiseRatio_CWVNC);
				result.println();
				System.out.println(dataSetName[i]+" complete!");
			}

			meanNoiseRatio_MV/=dataSetName.length;
			meanNoiseRatio_PL/=dataSetName.length;
			meanNoiseRatio_STC/=dataSetName.length;
			meanNoiseRatio_CC/=dataSetName.length;

			meanNoiseRatio_AVNC/=dataSetName.length;
			meanNoiseRatio_CENC/=dataSetName.length;
			meanNoiseRatio_LDNC/=dataSetName.length;
			meanNoiseRatio_CWVNC/=dataSetName.length;
			
			result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", "Mean",meanNoiseRatio_MV,meanNoiseRatio_PL,meanNoiseRatio_STC,meanNoiseRatio_CC,meanNoiseRatio_AVNC,meanNoiseRatio_CENC,meanNoiseRatio_LDNC,meanNoiseRatio_CWVNC);
			result.println();
			result.close();
			
			System.out.println("Complete!!!");
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
}
